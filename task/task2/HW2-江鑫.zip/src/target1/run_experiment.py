#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二次挑战 · 任务一 —— 实验执行器
==================================
严格按题目规定的流程执行，并采集每一项指标。

实验流程（顺序不可颠倒，否则数据会被污染）：

    ┌─ 首次实验前，只做一次 ──────────────────────────────┐
    │  服务预热：发 1 条短请求（不计入结果）                │
    └────────────────────────────────────────────────────┘
    ┌─ 每一组 ───────────────────────────────────────────┐
    │ ① 等待所有在飞请求结束                               │
    │ ② POST /flush_cache 并【确认成功】（双重 flush，见下）│
    │ ③ 仅共享前缀组：发 1 条前缀预热请求（不计入结果）     │
    │ ④ 最大并发 8，发 32 条测量请求，流式采集             │
    └────────────────────────────────────────────────────┘

用法：
    python run_experiment.py                     # 两组都跑（默认 Ray 引擎）
    python run_experiment.py --engine threads    # 用线程池引擎（Ray 出问题时用）
    python run_experiment.py --group shared      # 只跑共享前缀组
"""

import argparse
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor

import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *          # noqa: F401,F403


# ============================================================
# 一、底层：一条流式请求 + 打点
# ============================================================
def stream_generate(input_ids, timeout=600):
    """向 /generate 发一条流式请求，返回这条请求的完整测量记录。

    时间轴（这是 TTFT / TPOT 的定义来源）：

        t0 ─────────────────────────────────────────────────────►
             │←── TTFT ──→│
             │            │←──── 解码段（还剩 N-1 个 token）────→│
        发出请求      首个含文本的 chunk                     最后一个 chunk

        TTFT   = 排队 + Prefill + 第 1 次 Decode + 采样 + detokenize
        端到端 = TTFT + 解码段耗时
        TPOT   = 解码段耗时 / (completion_tokens − 1)

    为什么分母是 completion_tokens − 1：
        TTFT 里已经包含了"第 1 个 token"的时间，
        后面只剩 completion_tokens − 1 个 token 分摊剩下的时间。
    """
    body = {
        "input_ids": input_ids,
        "sampling_params": SAMPLING_PARAMS,
        "stream": True,
    }

    rec = {
        "prompt_tokens":     None,   # 服务实际处理的输入 token 数
        "completion_tokens": None,   # 实际生成的输出 token 数（应为 16）
        "cached_tokens":     None,   # ★ 命中 RadixCache 被复用的 token 数
        "finish_reason":     None,
        "ttft_s":            None,
        "e2e_s":             None,
        "tpot_s":            None,
        "n_chunks":          0,
        "status":            "unknown",
        "error":             None,
        "ts_start":          None,   # 绝对时刻（Linux CLOCK_MONOTONIC，跨进程可比）
        "ts_end":            None,
    }

    t0 = time.perf_counter()          # 单调时钟：测时间间隔必须用它，不能用 time.time()
    rec["ts_start"] = t0
    try:
        with requests.post(GENERATE_URL, json=body, stream=True, timeout=timeout) as resp:
            if resp.status_code != 200:
                rec["status"] = f"http_{resp.status_code}"
                rec["error"]  = resp.text[:300]
                rec["e2e_s"]  = time.perf_counter() - t0
                rec["ts_end"] = time.perf_counter()
                return rec

            for raw in resp.iter_lines(decode_unicode=False):
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="ignore").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[len("data:"):].strip()
                if payload == "[DONE]":
                    break
                try:
                    obj = json.loads(payload)
                except ValueError:
                    continue

                rec["n_chunks"] += 1

                # ① TTFT：第一个"真的有文本"的 chunk
                #    ⚠️ SGLang 的首个 chunk 可能只带 meta_info、text 为空。
                #       若把它当成首 token，TTFT 会被系统性低估 —— 必须判空。
                text = obj.get("text") or ""
                if text and rec["ttft_s"] is None:
                    rec["ttft_s"] = time.perf_counter() - t0

                # ② meta_info 里的 token 计数
                #    prompt_tokens / cached_tokens 通常在最后一个 chunk 才齐全，
                #    所以每个 chunk 都尝试更新一遍。
                mi = obj.get("meta_info") or {}
                for key in ("prompt_tokens", "completion_tokens", "cached_tokens", "finish_reason"):
                    if mi.get(key) is not None:
                        rec[key] = mi[key]

    except Exception as exc:                       # 网络错误 / 超时 / 服务异常
        rec["status"] = "exception"
        rec["error"]  = f"{type(exc).__name__}: {exc}"
        rec["e2e_s"]  = time.perf_counter() - t0
        rec["ts_end"] = time.perf_counter()
        return rec

    rec["ts_end"] = time.perf_counter()
    rec["e2e_s"]  = rec["ts_end"] - t0

    # ③ 成功判定：拿到满额输出且测到了 TTFT
    want = SAMPLING_PARAMS["max_new_tokens"]
    if rec["ttft_s"] is None:
        rec["status"] = "no_output"
    elif rec["completion_tokens"] != want:
        rec["status"] = f"short_output({rec['completion_tokens']})"
    else:
        rec["status"] = "success"
        # ④ TPOT = 解码段耗时 / 解码段 token 数
        if rec["completion_tokens"] > 1:
            rec["tpot_s"] = (rec["e2e_s"] - rec["ttft_s"]) / (rec["completion_tokens"] - 1)

    return rec


# ============================================================
# 二、流程控制：就绪检查 / 预热 / flush
# ============================================================
def wait_ready():
    """等 SGLang 的 /health 返回 200。"""
    for _ in range(60):
        try:
            if requests.get(HEALTH_URL, timeout=3).status_code == 200:
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


def _post_flush():
    try:
        resp = requests.post(FLUSH_CACHE_URL, timeout=30)
    except Exception as exc:
        return False, f"请求异常 {type(exc).__name__}: {exc}"
    if resp.status_code != 200:
        return False, f"HTTP {resp.status_code}: {resp.text[:200]}"
    return True, "ok"


def flush_cache_and_verify(probe_ids):
    """清空 RadixCache，并用一条无关的探测请求确认缓存真的空了。

    为什么要二次确认：
        /flush_cache 返回 200 只能说明"请求被接收了"，不能证明缓存真的空了。
        用一条与两组负载都无关的短请求探一下 cached_tokens 是否归零，
        才叫"确认成功"。

    为什么要 flush 两次：
        第一步的探测请求本身也会把自己的 KV 写进缓存。
        如果就此开始测量，那条探测请求的 token 会以极小概率给测量请求
        带来 1 个 token 的"意外命中"（实测确实出现过 cached_tokens=1）。
        所以确认之后再 flush 一次，把探测请求自己的残留也清掉，
        这样测量开始时缓存是真正干净的。
    """
    ok, msg = _post_flush()                       # 第一次：清掉上一组留下的缓存
    if not ok:
        return False, f"第一次 flush 失败：{msg}"

    probe = stream_generate(probe_ids)            # 探测：与两组负载都无关
    if probe["cached_tokens"] != 0:
        return False, f"探测请求 cached_tokens = {probe['cached_tokens']}（缓存似乎没清空）"

    ok, msg = _post_flush()                       # 第二次：清掉探测请求自己的残留
    if not ok:
        return False, f"第二次 flush 失败：{msg}"

    return True, "探测请求 cached_tokens = 0 ✔，并已清掉探测请求自身的残留"


# ============================================================
# 三、并发引擎
# ============================================================
def _run_threads(reqs, group):
    """线程池引擎：max_workers = 8 ⇒ 天然满足"最大并发数 8"。"""
    def one(item):
        rec = stream_generate(item["input_ids"])
        rec["index"] = item["index"]
        rec["group"] = group
        return rec

    with ThreadPoolExecutor(max_workers=MAX_CONCURRENCY) as pool:
        return list(pool.map(one, reqs))


# ---------------- Ray 引擎 ----------------
# actor 必须定义在模块级，Ray 才能正确序列化
try:
    import ray as _ray_mod
    _RAY_IMPORT_OK = True

    @_ray_mod.remote
    class RayRequestWorker:
        """一个 Ray actor = 一个并发槽。

        Ray actor 默认单线程，同一时刻只执行一条请求（run 是普通同步方法），
        因此创建 MAX_CONCURRENCY(=8) 个 actor，并发上限就精确是 8。
        """
        def run(self, index, group, input_ids):
            rec = stream_generate(input_ids)
            rec["index"] = index
            rec["group"] = group
            return rec
except Exception as _ray_err:          # noqa: BLE001
    _RAY_IMPORT_OK = False
    _RAY_IMPORT_ERR = _ray_err


def init_ray_cluster():
    """启动 Ray 本地集群并【预先创建】8 个 actor。

    这一步刻意放在计时窗口之外：
      actor 的创建要拉起新的 Python 进程（导入 ray / requests / 本模块），
      第一次创建尤其慢。如果把它算进实验的墙钟时间，
      算出来的吞吐量就会被进程启动开销污染。
    返回 actor 列表，供后续两组实验复用。
    """
    import logging
    if not _RAY_IMPORT_OK:
        raise RuntimeError(f"Ray 不可用：{_RAY_IMPORT_ERR}")

    t = time.perf_counter()
    if not _ray_mod.is_initialized():
        _ray_mod.init(ignore_reinit_error=True, include_dashboard=False,
                      logging_level=logging.ERROR)
    t_init = time.perf_counter() - t

    t = time.perf_counter()
    workers = [RayRequestWorker.remote() for _ in range(MAX_CONCURRENCY)]
    _ray_mod.get([w.__ray_ready__.remote() for w in workers])     # 等 actor 全部就绪
    t_actors = time.perf_counter() - t

    print(f"[Ray] 集群就绪（ray.init {t_init:.2f}s），"
          f"预创建 {len(workers)} 个 actor（{t_actors:.2f}s）"
          f"  ← 这段时间不计入吞吐量")
    print(f"[Ray] 可用资源 = {_ray_mod.cluster_resources()}")
    return workers


def _run_ray(reqs, group, workers):
    """把 32 条请求轮询分配给 8 个 actor 并收集结果。

    轮询分配（i % 8）：actor k 负责请求 k, k+8, k+16, k+24，
    串行执行自己那 4 条 ⇒ 任意时刻在飞请求数 ≤ 8。
    """
    futures = []
    for i, item in enumerate(reqs):
        w = workers[i % MAX_CONCURRENCY]
        futures.append(w.run.remote(item["index"], group, item["input_ids"]))
    return _ray_mod.get(futures)


# ============================================================
# 四、跑一组实验
# ============================================================
def run_group(group, payload, engine, workers=None):
    print("\n" + "=" * 72)
    print(f"【{group}】")
    print("=" * 72)

    # ① 等待在飞请求结束（每条请求都阻塞收完，这里再确认服务已就绪）
    wait_ready()

    # ② flush_cache 并确认成功
    ok, msg = flush_cache_and_verify(payload["probe"])
    print(f"[flush_cache] {'成功' if ok else '失败'} — {msg}")
    if not ok:
        raise RuntimeError("flush_cache 未确认成功，为保护数据干净性，终止本组实验")

    # ③ 前缀预热（仅共享前缀组）
    if payload.get("prefix_warmup"):
        rec = stream_generate(payload["prefix_warmup"])
        print(f"[前缀预热] prompt_tokens={rec['prompt_tokens']} "
              f"cached_tokens={rec['cached_tokens']} status={rec['status']}  "
              f"← 该请求不计入结果")
    else:
        print("[前缀预热] 本组不做前缀预热（题目要求）")

    # ④ 并发测量
    reqs = payload["requests"]
    print(f"[测量] {len(reqs)} 条请求，最大并发 {MAX_CONCURRENCY}，引擎 = {engine}")
    t_start = time.perf_counter()
    if engine == "ray":
        try:
            records = _run_ray(reqs, group, workers)
        except Exception as exc:                   # Ray 出错就自动回退
            print(f"[Ray] 失败（{type(exc).__name__}: {exc}），回退到线程池引擎")
            engine = "threads"
            records = _run_threads(reqs, group)
    else:
        records = _run_threads(reqs, group)
    wall = time.perf_counter() - t_start

    records.sort(key=lambda r: r["index"])

    result = {
        "group": group,
        "engine": engine,
        "n_requests": len(records),
        "max_concurrency": MAX_CONCURRENCY,
        "sampling_params": SAMPLING_PARAMS,
        "wall_time_s": round(wall, 4),
        "requests": records,
    }

    path = RESULT_SHARED if group == "shared_prefix" else RESULT_DISPERSED
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    n_ok = sum(1 for r in records if r["status"] == "success")
    sum_cached = sum(r["cached_tokens"] or 0 for r in records)
    sum_prompt = sum(r["prompt_tokens"] or 0 for r in records)
    print(f"[小结] 成功 {n_ok}/{len(records)}  墙钟 {wall:.2f}s  "
          f"Σcached_tokens={sum_cached}  Σprompt_tokens={sum_prompt}")
    print(f"[保存] -> {path}")
    return result


# ============================================================
# 五、主流程
# ============================================================
def main():
    ap = argparse.ArgumentParser(description="任务一：前缀缓存测量实验")
    ap.add_argument("--engine", choices=["ray", "threads"], default="ray",
                    help="并发引擎，默认 ray")
    ap.add_argument("--group", choices=["shared", "dispersed", "both"], default="both",
                    help="跑哪一组，默认两组都跑")
    args = ap.parse_args()

    ensure_dirs()

    if not wait_ready():
        print(f"[X] SGLang 服务未就绪（{HEALTH_URL}）。请先启动：~/start_sglang.sh")
        sys.exit(1)
    print(f"[OK] SGLang 服务就绪：{BASE_URL}")

    with open(PAYLOAD_SHARED, encoding="utf-8") as f:
        payload_shared = json.load(f)
    with open(PAYLOAD_DISPERSED, encoding="utf-8") as f:
        payload_dispersed = json.load(f)

    # ---- 准备并发引擎（放在计时之外） ----
    workers = None
    if args.engine == "ray":
        try:
            workers = init_ray_cluster()
        except Exception as exc:
            print(f"[Ray] 初始化失败（{type(exc).__name__}: {exc}），改用线程池引擎")
            args.engine = "threads"

    # ---- 首次实验前：服务预热（只做一次，不计入结果） ----
    rec = stream_generate(payload_shared["warmup_short"])
    print(f"[服务预热] prompt_tokens={rec['prompt_tokens']} status={rec['status']} "
          f"e2e={rec['e2e_s']:.3f}s  ← 不计入结果")

    if args.group in ("shared", "both"):
        run_group("shared_prefix", payload_shared, args.engine, workers)
    if args.group in ("dispersed", "both"):
        run_group("dispersed_prefix", payload_dispersed, args.engine, workers)

    print("\n[OK] 实验结束。下一步：python summarize.py")


if __name__ == "__main__":
    main()
# 结束