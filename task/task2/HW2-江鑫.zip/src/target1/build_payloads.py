#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二次挑战 · 任务一 —— 负载构造
================================
按题目要求构造两组输入，**唯一的变量是"前缀是否共享"**：

    共享前缀组： input_ids_i = P(2048，所有请求共用)   + S_i(64)     共 2112
    分散前缀组： input_ids_i = R_i(2048，两两不同)     + S_i(64)     共 2112

三条设计要点（对应 PDF 里的那张表）：
  1. 两组共用同一批后缀 S_i
     → 后缀内容、输入长度、请求顺序全部一致，只有前缀不同（控制变量法）
  2. 两组每条长度都严格是 2112
     → 满足"输入长度一致"的完成标准
  3. 分散组每个 R_i 的【首个 token 各不相同】
     → 前缀匹配是从 token 0 开始逐位比对的，首个 token 不同
       ⇒ 最长公共前缀 = 0 ⇒ cached_tokens 必然为 0
     这是"分散前缀"的严格保证，而不是"碰运气不重合"

产物：
    results/payloads_shared_prefix.json
    results/payloads_dispersed_prefix.json
每个文件结构：
    {
      "meta": {...},
      "probe":         [...],   # flush_cache 之后用来探测缓存是否真的空了的短请求
      "warmup_short":  [...],   # 首次实验前的服务预热短请求
      "prefix_warmup": [...],   # 前缀预热请求（仅共享前缀组有）
      "requests":      [ {"index":0,"input_ids":[...]}, ... ]   # 32 条测量请求
    }

用法：python build_payloads.py
"""

import json
import os
import random
import sys

from transformers import AutoTokenizer

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *          # noqa: F401,F403


# ============================================================
# 一、准备语料池
# ============================================================
def load_corpus_tokens(tokenizer):
    """从本地若干文本文件里读取真实文本，编码成 token 序列作为"语料池"。

    为什么用真实文本而不是随机整数：
      · 真实文本编码出的 token 组合自然，不会误撞 special token
      · 更贴近真实业务请求的 token 分布
    """
    chunks = []
    for path in CORPUS_FILES:
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            chunks.append(f.read(CORPUS_MAX_CHARS_PER_FILE))
        if sum(len(c) for c in chunks) >= CORPUS_MAX_CHARS_PER_FILE * 2:
            break
    if not chunks:
        raise RuntimeError(f"语料文件全都不存在，请检查 config.CORPUS_FILES = {CORPUS_FILES}")

    text = "\n".join(chunks)
    ids = tokenizer.encode(text, add_special_tokens=False)
    print(f"[语料] 读取字符数 = {len(text):,}，编码后 token 数 = {len(ids):,}")
    return ids


# ============================================================
# 二、构造两组负载
# ============================================================
def build_all():
    ensure_dirs()

    tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
    vocab_size = tokenizer.vocab_size
    print(f"[模型] tokenizer 载入完成，vocab_size = {vocab_size}")

    pool = load_corpus_tokens(tokenizer)

    # 需要多少 token：P + 32 个 R + 32 个 S + 探测/预热请求 + 余量
    need = SHARED_PREFIX_LEN + N_REQ * SHARED_PREFIX_LEN + N_REQ * SUFFIX_LEN + 2048
    if len(pool) < need:
        reps = need // len(pool) + 1
        pool = pool * reps
        print(f"[语料] 不足 {need}，重复 {reps} 次扩充到 {len(pool):,} tokens")
    pool = pool[: need + 4096]

    # 打乱语料池：这样后面各个切片互不相同，避免"分散组之间意外共享前缀"
    rng = random.Random(BUILD_SEED)
    rng.shuffle(pool)

    off = 0

    # ① 共享前缀 P
    P = pool[off: off + SHARED_PREFIX_LEN]
    off += SHARED_PREFIX_LEN

    # ② 分散组的 32 个互不相同前缀 R_i
    R = []
    for _ in range(N_REQ):
        R.append(list(pool[off: off + SHARED_PREFIX_LEN]))
        off += SHARED_PREFIX_LEN

    # ③ 两组共用的 32 个独立后缀 S_i
    S = []
    for _ in range(N_REQ):
        S.append(list(pool[off: off + SUFFIX_LEN]))
        off += SUFFIX_LEN

    # ④ ★ 强制分散组"首个 token 各不相同"（题目表的硬性要求）
    first_tokens = list(dict.fromkeys(pool[off: off + 1024]))    # 去重后取前 32 个
    assert len(first_tokens) >= N_REQ, "语料池里不同 token 不足，请增加语料"
    for i in range(N_REQ):
        R[i][0] = first_tokens[i]
    off += 1024

    # ⑤ 探测请求 / 服务预热请求（与两组负载无关，避免污染缓存）
    probe        = list(pool[off: off + 32]);  off += 32
    warmup_short = list(pool[off: off + 32]);  off += 32

    # ---------------- 组装 ----------------
    shared_requests = [
        {"index": i, "input_ids": list(P) + list(S[i])} for i in range(N_REQ)
    ]
    dispersed_requests = [
        {"index": i, "input_ids": list(R[i]) + list(S[i])} for i in range(N_REQ)
    ]

    meta = {
        "shared_prefix_len": SHARED_PREFIX_LEN,
        "suffix_len": SUFFIX_LEN,
        "total_len": TOTAL_LEN,
        "n_requests": N_REQ,
        "build_seed": BUILD_SEED,
        "vocab_size": vocab_size,
    }

    payload_shared = {
        "meta": meta,
        "probe": probe,
        "warmup_short": warmup_short,
        "prefix_warmup": list(P),          # 前缀预热 = 共享前缀本身
        "requests": shared_requests,
    }
    payload_dispersed = {
        "meta": meta,
        "probe": probe,
        "warmup_short": warmup_short,
        "prefix_warmup": None,             # 分散前缀组不做前缀预热
        "requests": dispersed_requests,
    }

    # ---------------- 自检（这一步很重要，错了整组实验都废） ----------------
    print("\n[自检]")
    all_reqs = shared_requests + dispersed_requests
    assert all(len(x["input_ids"]) == TOTAL_LEN for x in all_reqs), "长度必须都是 2112"
    print(f"  ✔ 两组每条输入长度均为 {TOTAL_LEN}")

    base = shared_requests[0]["input_ids"][:SHARED_PREFIX_LEN]
    assert all(x["input_ids"][:SHARED_PREFIX_LEN] == base for x in shared_requests)
    print(f"  ✔ 共享前缀组前 {SHARED_PREFIX_LEN} 个 token 完全一致")

    firsts = [x["input_ids"][0] for x in dispersed_requests]
    assert len(set(firsts)) == N_REQ, "分散组首个 token 必须两两不同"
    print(f"  ✔ 分散前缀组首个 token 两两不同（{len(set(firsts))} 个不同值）⇒ 最长公共前缀 = 0")

    for a, b in zip(shared_requests, dispersed_requests):
        assert a["input_ids"][SHARED_PREFIX_LEN:] == b["input_ids"][SHARED_PREFIX_LEN:]
    print(f"  ✔ 两组后缀逐位相同（各 {SUFFIX_LEN} token）")

    # ---------------- 落盘 ----------------
    with open(PAYLOAD_SHARED, "w", encoding="utf-8") as f:
        json.dump(payload_shared, f, ensure_ascii=False)
    with open(PAYLOAD_DISPERSED, "w", encoding="utf-8") as f:
        json.dump(payload_dispersed, f, ensure_ascii=False)
    print(f"\n[保存] -> {PAYLOAD_SHARED}")
    print(f"[保存] -> {PAYLOAD_DISPERSED}")

    # 打印一份对照说明，方便写报告
    print("\n[负载摘要]")
    print(f"  共享前缀组：每条 = 2048 token 共享前缀 + 64 token 独立后缀 = 2112")
    print(f"  分散前缀组：每条 = 2048 token 独有前缀 + 64 token 独立后缀 = 2112")
    print(f"  两组后缀完全相同，长度完全相同，顺序完全相同")


if __name__ == "__main__":
    build_all()