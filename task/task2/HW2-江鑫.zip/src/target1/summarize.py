#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二次挑战 · 任务一 —— 指标汇总
================================
读取两组逐请求结果，按题目要求计算主表：

    成功率 / 吞吐量 / 缓存命中率 / 实际执行 Prefill 的 token 数
    TTFT、TPOT、端到端延迟 的 p50 与 p95

题目给定的两个公式：
    缓存命中率            = sum(cached_tokens) / sum(prompt_tokens)
    实际 Prefill token 数 = sum(prompt_tokens − cached_tokens)

输出：
    results/summary.md     （可直接贴进报告）

用法：python summarize.py
"""

import json
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *          # noqa: F401,F403


def percentile(values, q):
    """分位数。p50 = 中位数；p95 = 最差 5% 的门槛。

    为什么不用平均值：均值会被长尾拉偏，掩盖真实分布；
    线上服务真正关心"最倒霉的那批用户"的体验，即 p95。
    """
    return float(np.percentile(values, q))


def summarize_one(data):
    reqs = data["requests"]
    n = len(reqs)
    ok = [r for r in reqs if r["status"] == "success"]

    sum_prompt = sum((r["prompt_tokens"] or 0) for r in reqs)
    sum_cached = sum((r["cached_tokens"] or 0) for r in reqs)
    sum_comp   = sum((r["completion_tokens"] or 0) for r in reqs)
    wall       = data["wall_time_s"]

    out = {
        "group":                 data["group"],
        "engine":                data["engine"],
        "n_requests":            n,
        "n_success":             len(ok),
        "success_rate":          len(ok) / n if n else 0.0,
        "wall_time_s":           wall,
        # 吞吐量（两种口径都给出，报告里要写明用的是哪一种）
        "throughput_req_per_s":  n / wall if wall else 0.0,
        "throughput_tok_per_s":  sum_comp / wall if wall else 0.0,
        "sum_prompt_tokens":     sum_prompt,
        "sum_cached_tokens":     sum_cached,
        "sum_completion_tokens": sum_comp,
        # 题目给定公式
        "cache_hit_rate":        (sum_cached / sum_prompt) if sum_prompt else 0.0,
        "actual_prefill_tokens": sum_prompt - sum_cached,
        # 每条请求的平均输入/输出长度（用来证明"两组长度一致"）
        "avg_prompt_tokens":     sum_prompt / n if n else 0.0,
        "avg_completion_tokens": sum_comp / n if n else 0.0,
    }

    for name, field in (("ttft", "ttft_s"), ("tpot", "tpot_s"), ("e2e", "e2e_s")):
        vals = [r[field] for r in ok if r.get(field) is not None]
        if vals:
            out[f"{name}_p50_s"]  = percentile(vals, 50)
            out[f"{name}_p95_s"]  = percentile(vals, 95)
            out[f"{name}_mean_s"] = float(np.mean(vals))
            out[f"{name}_min_s"]  = float(np.min(vals))
            out[f"{name}_max_s"]  = float(np.max(vals))
    return out


def fmt(x, nd=4):
    return "—" if x is None else f"{x:.{nd}f}"


def main():
    if not (os.path.exists(RESULT_SHARED) and os.path.exists(RESULT_DISPERSED)):
        print("❌ 缺少逐请求结果，请先运行 run_experiment.py")
        sys.exit(1)

    with open(RESULT_SHARED, encoding="utf-8") as f:
        d_shared = json.load(f)
    with open(RESULT_DISPERSED, encoding="utf-8") as f:
        d_disp = json.load(f)

    s_shared = summarize_one(d_shared)
    s_disp   = summarize_one(d_disp)

    # ---------------- 控制台 / markdown 对照表 ----------------
    rows = [
        ("成功率",                    "success_rate",          "{:.1%}",  s_shared, s_disp),
        ("吞吐量 (req/s)",            "throughput_req_per_s",  "{:.3f}",  s_shared, s_disp),
        ("吞吐量 (output tok/s)",     "throughput_tok_per_s",  "{:.2f}",  s_shared, s_disp),
        ("平均输入长度 (token)",      "avg_prompt_tokens",     "{:.1f}",  s_shared, s_disp),
        ("平均输出长度 (token)",      "avg_completion_tokens", "{:.1f}",  s_shared, s_disp),
        ("缓存命中率",                "cache_hit_rate",        "{:.2%}",  s_shared, s_disp),
        ("实际 Prefill token 数",     "actual_prefill_tokens", "{:.0f}",  s_shared, s_disp),
        ("TTFT p50 (s)",              "ttft_p50_s",            "{:.4f}",  s_shared, s_disp),
        ("TTFT p95 (s)",              "ttft_p95_s",            "{:.4f}",  s_shared, s_disp),
        ("TPOT p50 (s)",              "tpot_p50_s",            "{:.4f}",  s_shared, s_disp),
        ("TPOT p95 (s)",              "tpot_p95_s",            "{:.4f}",  s_shared, s_disp),
        ("端到端 p50 (s)",            "e2e_p50_s",             "{:.4f}",  s_shared, s_disp),
        ("端到端 p95 (s)",            "e2e_p95_s",             "{:.4f}",  s_shared, s_disp),
    ]

    lines = []
    lines.append("# 任务一：前缀缓存效果对照表\n")
    lines.append(f"- 共享前缀组引擎：{s_shared['engine']}；分散前缀组引擎：{s_disp['engine']}")
    lines.append(f"- 每组请求数：{s_shared['n_requests']}；最大并发：{d_shared['max_concurrency']}")
    lines.append(f"- 采样参数：`{json.dumps(d_shared['sampling_params'], ensure_ascii=False)}`\n")
    lines.append("| 指标 | 共享前缀组 | 分散前缀组 |")
    lines.append("|---|---|---|")
    for label, key, f, a, b in rows:
        va = a.get(key)
        vb = b.get(key)
        fa = fmt(va) if va is None else f.format(va)
        fb = fmt(vb) if vb is None else f.format(vb)
        lines.append(f"| {label} | {fa} | {fb} |")

    md = "\n".join(lines)
    print("\n" + md + "\n")

    # ---------------- 落盘 ----------------
    ensure_dirs()
    with open(SUMMARY_MD, "w", encoding="utf-8") as f:
        f.write(md + "\n")

    print(f"[保存] -> {SUMMARY_MD}")

    # ---------------- 自动核查"完成标准" ----------------
    print("\n[完成标准核查]")
    print(f"  两组请求全部成功           : "
          f"{'✔' if s_shared['success_rate'] == 1 and s_disp['success_rate'] == 1 else '✘'}")
    print(f"  两组输入长度一致           : "
          f"{'✔' if abs(s_shared['avg_prompt_tokens'] - s_disp['avg_prompt_tokens']) < 1e-6 else '✘'}")
    print(f"  两组输出长度一致           : "
          f"{'✔' if abs(s_shared['avg_completion_tokens'] - s_disp['avg_completion_tokens']) < 1e-6 else '✘'}")
    print(f"  共享组命中率更高           : "
          f"{'✔' if s_shared['cache_hit_rate'] > s_disp['cache_hit_rate'] else '✘'}")
    print(f"  共享组实际 Prefill 更少    : "
          f"{'✔' if s_shared['actual_prefill_tokens'] < s_disp['actual_prefill_tokens'] else '✘'}")


if __name__ == "__main__":
    main()