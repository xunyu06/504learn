#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
第二次挑战 · 任务一 —— 全局配置
================================
所有实验参数集中在这里，目的是保证两组实验
「除前缀能否复用外，模型、输入与输出长度、请求顺序和并发数均保持一致」。
"""

import os

# ---------------- 服务地址（本地 SGLang） ----------------
BASE_URL        = "http://127.0.0.1:30000"
GENERATE_URL    = BASE_URL + "/generate"       # 原生推理接口（发送 input_ids）
FLUSH_CACHE_URL = BASE_URL + "/flush_cache"    # 清空 RadixCache
HEALTH_URL      = BASE_URL + "/health"

# ---------------- 模型（只用来读 tokenizer / vocab_size） ----------------
MODEL_DIR = "/home/jiang/models/Qwen3-0.6B"

# ---------------- 实验规模（题目硬性要求） ----------------
N_REQ             = 32      # 每组 32 条测量请求
MAX_CONCURRENCY   = 8       # 最大并发数 8
SHARED_PREFIX_LEN = 2048    # 共享前缀 2048 个 token
SUFFIX_LEN        = 64      # 独立后缀 64 个 token
TOTAL_LEN         = SHARED_PREFIX_LEN + SUFFIX_LEN      # = 2112

# ---------------- 采样参数（题目硬性要求，两组必须完全一致） ----------------
SAMPLING_PARAMS = {
    "temperature":    0,     # 贪心解码：结果完全确定，消除采样噪声
    "max_new_tokens": 16,    # 输出上限 16 个 token
    "ignore_eos":     True,  # ★ 忽略 EOS，强制生成满 16 个
                             #   → 保证 32 条请求输出长度严格一致，
                             #     否则 TPOT 无法在两组之间比较
    "sampling_seed":  2026,  # 固定随机种子（题目要求）
}

# ---------------- 负载构造用的随机种子（保证负载可复现） ----------------
BUILD_SEED = 2026

# ---------------- 目录结构 ----------------
# 本文件位于 HW2-姓名/src/target1/config.py，故向上退三层才是仓库根目录
ROOT        = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC_DIR     = os.path.join(ROOT, "src", "target1")      # HW2-姓名/src/target1/
DATA_DIR    = os.path.join(SRC_DIR, "data")              # HW2-姓名/src/target1/data/
RESULTS_DIR = os.path.join(ROOT, "results", "target1")   # HW2-姓名/results/target1/

DIR_SHARED    = os.path.join(RESULTS_DIR, "shared_prefix")
DIR_DISPERSED = os.path.join(RESULTS_DIR, "dispersed_prefix")

# 负载与逐请求结果都归入各自的组目录：
#   results/target1/shared_prefix/     <- 共享前缀组的一切
#   results/target1/dispersed_prefix/  <- 分散前缀组的一切
PAYLOAD_SHARED    = os.path.join(DIR_SHARED,    "payloads_shared_prefix.json")
PAYLOAD_DISPERSED = os.path.join(DIR_DISPERSED, "payloads_dispersed_prefix.json")

RESULT_SHARED    = os.path.join(DIR_SHARED,    "requests.json")
RESULT_DISPERSED = os.path.join(DIR_DISPERSED, "requests.json")

SUMMARY_MD   = os.path.join(RESULTS_DIR, "summary.md")

# ---------------- 语料来源（用真实文本生成 token 序列） ----------------
# 说明：直接用随机 token id 也能跑，但真实文本编码出来的 token 序列更自然，
#       也天然避开 special token。
# 语料已随交付包提供在 HW2-姓名/src/target1/data/ 下（详见 README「3.0 语料来源」），
# 内容分别原样取自：Qwen3-0.6B 模型仓库 README、第一关 mooncake trace 的前 200000 字符、
# sglang 0.5.14 的 srt/mem_cache/radix_cache.py。
# 三个文件的顺序与每个文件最多读取的字符数（CORPUS_MAX_CHARS_PER_FILE）必须保持不变，
# 否则 token 序列会变、负载会变、实验结果无法对照。
CORPUS_FILES = [
    os.path.join(DATA_DIR, "corpus_01.txt"),
    os.path.join(DATA_DIR, "corpus_02.txt"),
    os.path.join(DATA_DIR, "corpus_03.txt"),
]
CORPUS_MAX_CHARS_PER_FILE = 200_000       # 每个文件最多取这么多字符，避免读太久


def ensure_dirs():
    """创建所有输出目录。"""
    for d in (RESULTS_DIR, DIR_SHARED, DIR_DISPERSED):
        os.makedirs(d, exist_ok=True)