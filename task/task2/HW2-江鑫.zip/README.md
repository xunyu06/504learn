# 第二次挑战·任务1
> 环境:wsl2+SGLang0.5.14+Qwen/Qwen3-0.6B
> src/target1/data 里是构造负载用的语料库文件。
## 一、GPU与软件版本
| 项目 | 版本 |
|---|---|
| GPU | NVIDIA GeForce RTX 4060 Laptop GPU |
| 操作系统 | Ubuntu 24.04 LTS（WSL2） |
| Python | 3.12.14 conda环境 |
| CUDA（torch 运行时） | 13.0 |
| PyTorch | 2.11.0+cu130 |
| SGLang | 0.5.14 |
| Ray | 2.56.0 |
| transformers | 5.8.1 |
| tokenizers | 0.22.2 |
| flashinfer-python / flashinfer-cubin | 0.6.12 |
| openai | 2.6.1 |
| 模型 | `Qwen/Qwen3-0.6B`|
## 二、安装方法
### 2.1 环境创建（AI主导教学）

```bash
# 安装 Miniconda 到 ~/miniconda3
conda create -n west2 python=3.12 -y
conda activate west2

# 安装 SGLang 与 Ray
pip install sglang==0.5.14 ray==2.56.0

# 下载模型（ModelScope)
pip install modelscope
modelscope download --model Qwen/Qwen3-0.6B --local_dir ~/models/Qwen3-0.6B
```
### 2.2 pip 环境的四个CUDA相关修复（AI修复环境）
本机用 pip 安装的 PyTorch，其 CUDA 组件不在 `/usr/local/cuda`，直接运行官方启动命令
会因找错头文件/库路径而失败。共踩到四个坑：

| # | 报错原文 | 原因 | 修复 |
|---|---|---|---|
| ① | `Could not find nvcc and default cuda_home='/usr/local/cuda' doesn't exist` | 本机没有系统级 CUDA Toolkit，nvcc 在 pip wheel 里 | `export CUDA_HOME=$SP/nvidia/cu13` |
| ② | `fatal error: nv/target: No such file or directory` | 全机唯一的 CCCL 头文件在 flashinfer 内 | `export NVCC_PREPEND_FLAGS="-I$SP/flashinfer/data/cccl/libcudacxx/include"` |
| ③ | `#error "CUDA compiler and CUDA toolkit headers are incompatible"` | nvcc 13.2 与 cudart 13.0 的版本号检查永不相等 | 在 ② 的变量后追加 `-DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK` |
| ④ | 链接期 `cannot find -lcudart` / `-lcuda` | pip 布局只有 `lib/`，nvcc 找 `lib64/`；且缺 `libcuda` 存根 | 建符号链接（一次性，见下） |

其中 ①②③ 已在 `~/start_sglang.sh` 里解决，④ 需要在安装阶段执行一次：

```bash
SP=$HOME/miniconda3/envs/west2/lib/python3.12/site-packages
CUDA_HOME=$SP/nvidia/cu13
ln -s lib $CUDA_HOME/lib64
ln -s /usr/lib/wsl/lib/libcuda.so.1 $CUDA_HOME/lib/stubs/libcuda.so
ln -s /usr/lib/wsl/lib/libcuda.so.1 $CUDA_HOME/lib/libcuda.so
```
## 三、启动与回放
### 3.0 语料来源

`build_payloads.py` 需要一段足够长的文本，把它编码成 token 序列作为负载原料。
为避免依赖任何外部资源，语料已随交付包提供在 `src/target1/data/` 下：

| 文件 | 字符数 | 内容 | 原样取自 |
|---|---|---|---|
| `src/target1/data/corpus_01.txt` | 13,965 | Markdown 文档 | Qwen/Qwen3-0.6B 模型仓库的 `README.md` |
| `src/target1/data/corpus_02.txt` | 200,000 | JSON Lines | 第一关下载的 `mooncake_trace.jsonl` 的前 200,000 个字符 |
| `src/target1/data/corpus_03.txt` | 30,685 | Python 源码 | sglang 0.5.14 的 `srt/mem_cache/radix_cache.py` |
### 3.1 启动服务
> 由于AI构造的环境是wsl2+pip安装的pytorch环境，所以无法用官方命令启动服务，CUDA头文件与库路径问题导致启动失效，所以让ai帮我写了一个启动脚本，如下，后续启动sglang都用此脚本。
```bash
bash ~/start_sglang.sh
```
`~/start_sglang.sh` 的内容：
```bash
SP=$HOME/miniconda3/envs/west2/lib/python3.12/site-packages
export CUDA_HOME=$SP/nvidia/cu13
export PATH=$CUDA_HOME/bin:$HOME/miniconda3/envs/west2/bin:$PATH
export NVCC_PREPEND_FLAGS="-I$SP/flashinfer/data/cccl/libcudacxx/include -DCCCL_DISABLE_CTK_COMPATIBILITY_CHECK"
exec python -m sglang.launch_server \
    --model-path $HOME/models/Qwen3-0.6B \
    --served-model-name Qwen/Qwen3-0.6B \
    --host 0.0.0.0 --port 30000 \
    --attention-backend triton \
    --cuda-graph-backend-prefill disabled \
    --mem-fraction-static 0.6
```
### 3.2 确认服务启动
```bash
curl -s http://127.0.0.1:30000/health
curl -s http://127.0.0.1:30000/v1/models
```
输出200就是服务启动成功，第二条是确认模型是Qwen/Qwen3-0.6B。
### 3.3 回放
参数来自 `config.py`
。
- 三条命令逐次进行

```bash
bash ~/start_sglang.sh 
python src/target1/build_payloads.py                                   
python src/target1/run_experiment.py --engine ray --group both
python src/target1/summarize.py
```
分别是：
1. 构造两组不同的负载，一个是共享前缀，一个是分散前缀。
2. 发送请求，开始进行计时，生成JSON文件，记录请求服务的输出内容，比如p95，TTFT,TPOT等。
3. 汇总结果。
## 四、脚本用途

| 脚本 | 用途 |
|---|---|
| `src/target1/config.py` | 参数与路径部分，包含temperature等任务要求参数。 |
| `src/target1/build_payloads.py` | 构造两组负载。读取本机三个文本文件（模型 README、Mooncake trace 前 200,000 字符、SGLang `radix_cache.py`）作为语料池（这是AI选取的语料库，直接从我的文件中获取,最后变成了data里面的corpus三个文件）；按 `BUILD_SEED=2026` 打乱后顺序得到 P、R[32]、S[32]，最后得到首个 token 两两不同的分散组以及相反的共享组。|
| `src/target1/run_experiment.py` | 通过 `/generate` 接口发送 `input_ids`，以 `stream=True` 流式接收；客户端记录 TTFT、端到端延迟并计算 TPOT；并发由 Ray actor 提供8 个 worker；每组测量前清空缓存，共享组额外发送前缀预热请求。 |
| `src/target1/summarize.py` | 读取两组 `requests.json`，计算成功率、吞吐量、缓存命中率、实际 Prefill token 数、TTFT/TPOT/端到端延迟的 p50 与 p95，输出 `summary.md`； |
## 五、结果目录与报告表格的对应关系

| 结果文件 | 内容 |
|---|---|
| `results/target1/summary.md` | 汇总表：成功率、吞吐量、平均输入、输出长度、缓存命中率、实际Prefill token数、TTFT/TPOT/端到端延迟的 p50 与 p95 |
| `results/target1/shared_prefix/requests.json` | 共享前缀组请求记录 |
| `results/target1/dispersed_prefix/requests.json` | 分散前缀组请求记录 |
| `results/target1/shared_prefix/payloads_shared_prefix.json` | 共享组发送的负载  |
| `results/target1/dispersed_prefix/payloads_dispersed_prefix.json` | 分散组发送的负载|
